//
//  SeperatorFullWidhCell.swift
//  JoggleApp
//
//  Created by Admin on 16/11/18.
//  Copyright © 2018 Abichal. All rights reserved.
//

import UIKit

class SeperatorFullWidhCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
     
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    
}
