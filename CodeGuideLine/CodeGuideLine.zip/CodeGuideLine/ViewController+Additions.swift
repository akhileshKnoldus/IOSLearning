//
//  ViewController+Additions.swift
//  CodeGuideLine
//
//  Created by Akhilesh Gupta on 30/10/18.
//  Copyright © 2018 appventurez. All rights reserved.
//

import Foundation

extension ViewController {
    
    func myCustomFunction() {
        
    }
}
