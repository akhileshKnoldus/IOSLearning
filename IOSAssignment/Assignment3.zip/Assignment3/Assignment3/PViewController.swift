//
//  PViewController.swift
//  Assignment3
//
//  Created by Akhilesh Gupta on 10/10/18.
//  Copyright © 2018 appventurez. All rights reserved.
//

import UIKit

class PViewController: UIViewController {
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var ageTextField: UITextField!
    @IBOutlet weak var dobTextField: UITextField!
    @IBOutlet weak var notesTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func moveToAdressVC(){
        let sb = UIStoryboard(name: "Main", bundle: nil)
       // print(sb)
        if let addVC = sb.instantiateViewController(withIdentifier: "AViewController")as? AViewController
        {
           // addVC.name = nameTextField.text
            addVC.dataInfo.append(nameTextField.text!)
            addVC.dataInfo.append(emailTextField.text!)
            addVC.dataInfo.append(ageTextField.text!)
            addVC.dataInfo.append(dobTextField.text!)
            addVC.dataInfo.append(notesTextView.text!)
            self.navigationController?.pushViewController(addVC, animated: true)
        }
    }

    @IBAction func tappedNextbtn(_ sender: Any) {
       moveToAdressVC()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
