//
//  AViewController.swift
//  Assignment3
//
//  Created by Akhilesh Gupta on 10/10/18.
//  Copyright © 2018 appventurez. All rights reserved.
//
import UIKit

class AViewController: UIViewController {
    
    @IBOutlet weak var adress1TextField: UITextField!
    @IBOutlet weak var adress2TextField: UITextField!
    @IBOutlet weak var cityTextField: UITextField!
    @IBOutlet weak var zipTextField: UITextField!
    @IBOutlet weak var stateTextField: UITextField!
    @IBOutlet weak var permanentAdress: UITextView!
   
    var personalinfo = [String]()
    var dataInfo = [String]()
    var addname = [String]()
    var adddata = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.personalInfoArray()
       
        // Do any additional setup after loading the view.
    }
    
    func personalInfoArray(){
        personalinfo.append("Name")
        personalinfo.append("Age")
        personalinfo.append("Email")
        personalinfo.append("Address")
        personalinfo.append("Dob")
        addname.append("Address1")
         addname.append("Address1")
         addname.append("ZipCode")
         addname.append("City")
        addname.append("State")
         addname.append("Padress")
        
    }
    func moveToDisplayVC(){
        let sb = UIStoryboard(name: "Main", bundle: nil)
        if let disp=sb.instantiateViewController(withIdentifier: "DViewController") as? DViewController
        {
            disp.data=dataInfo
            disp.filedname=personalinfo
            disp.adddata.append(adress1TextField.text!)
            disp.adddata.append(adress2TextField.text!)
            disp.adddata.append(zipTextField.text!)
            disp.adddata.append(cityTextField.text!)
            disp.adddata.append(stateTextField.text!)
            disp.adddata.append(permanentAdress.text!)
            disp.addfiledname=addname
            self.navigationController?.pushViewController(disp, animated: false)
        }
    }
    
    
    
    @IBAction func tappedSubmitBtn(_ sender: Any) {
    }
    
    
    @IBAction func adressSubmitBtn(_ sender: Any) {
        moveToDisplayVC()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }
    
    

}
