//
//  ViewController.swift
//  Assignment3
//
//  Created by Akhilesh Gupta on 10/10/18.
//  Copyright © 2018 appventurez. All rights reserved.
//

import UIKit
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func moveToPersonalVC(){
        let sb = UIStoryboard(name: "Main", bundle: nil)
       // print(sb)
        if let pVC = sb.instantiateViewController(withIdentifier: "PViewController") as? PViewController
        {
            self.navigationController?.pushViewController(pVC, animated: true)
           // print("Inside Tapped BTN")
        }
    }
    
    @IBAction func tapSubmit(_ sender: Any) {
        moveToPersonalVC()
    }
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

