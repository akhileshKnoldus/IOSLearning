//
//  EmplloyeeViewController.swift
//  EmployeeDetails
//
//  Created by Akhilesh Gupta on 12/10/18.
//  Copyright © 2018 appventurez. All rights reserved.
//

import UIKit

class EmplloyeeViewController: UIViewController ,UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    
    @IBOutlet weak var collectionViewDemo: UICollectionView!
    
    @IBOutlet weak var serachTextField: UITextField!
    
    var employeeInfo: [[String: AnyObject]]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerNib()
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func registerNib(){
        let nib = UINib(nibName: "EmployeeCollectionViewCell", bundle: nil)
        self.collectionViewDemo.register(nib, forCellWithReuseIdentifier: "EmployeeCollectionViewCell")
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return employeeInfo!.count
    }
    
  
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "EmployeeCollectionViewCell", for: indexPath) as? EmployeeCollectionViewCell{
            
            //  cell.btnDetail.addTarget(self, action: #selector(tapDetail(_:)), for: .touchUpInside)
            // cell.btnOutlet.addTarget(self, action:#selector(btnTapped(_:)), for: .touchUpInside)
            
            
            if let arrDataSource = self.employeeInfo {
                let data = arrDataSource[indexPath.row]
                
                if let name = data["name"] as? String {
                    cell.nameUILabel.text = name
                }
                if let profile = data["profile"] as? String {
                    cell.profileLabel.text = profile
                }
                
                if let image = data["image"] as? UIImage {
                    cell.imageView.image = image
                }
            }
            
            return cell 
        }
        return UICollectionViewCell()
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 200, height: 200)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 4.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 4.0
    }
    
    @IBAction func searchSubmitBtn(_ sender: Any) {
        
    }
    
    
}


