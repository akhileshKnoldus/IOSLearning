//
//  UploadNewVegitableCustomCollectionViewCell.swift
//  ImageUploadAssigmnet
//
//  Created by Akhilesh Gupta on 17/10/18.
//  Copyright © 2018 appventurez. All rights reserved.
//

import UIKit

class UploadNewVegitableCustomCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imgVegitable: UIImageView!
     
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
   
}
